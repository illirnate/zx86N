Adobe CC 2015 Universal Patcher 1.5
amtemu.v0.9.1.win-painter
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Does Adobe products from CS4 till CC 2015

adobe.snr.patch.v2.0-painter
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Does Adobe products from CS4 till CC 2017

Adobe CC 2015.5 XFORCE Activation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Only does Adobe products from CC (eg. Adobe Photoshop CC, Premiere CC, yada yada yada you get the point.